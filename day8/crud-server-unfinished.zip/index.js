let express = require("express");
let mongoose = require("mongoose");
let cors = require("cors");
let config = require("./config.json");

// configure express
let app = express();
app.use(express.json());
// configure database
// create a model object
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let heromodel = {
    id : ObjectId,
    firstname : String,
    lastname : String,
    power : Number,
    city : String
}
let Hero = mongoose.model("Hero",new Schema(heromodel));
mongoose.connect(config.url.replace("<username>",config.username).replace("<password>", config.password))
.then(res => console.log("DB connected"))
.catch(error => console.log("Error ", error));

// configure routes
app.get("/data", (req, res)=>{
    // res.send("hello from express")
    Hero.find(function(error, dbres){
        res.send(dbres);
    })
})
// configure web server
// app.listen(5050,"localhost", error => error ? console.log("Error ", error) : console.log("server is now running on localhost:5050"))
app.listen(config.port,config.host, function(error){
    if(error){
        console.log("Error ", error)
    }else{
        console.log("Server is now live on localhost:5050")
    }
})

