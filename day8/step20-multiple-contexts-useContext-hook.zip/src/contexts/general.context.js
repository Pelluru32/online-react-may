import React from "react";

let GenContext = React.createContext();

export default GenContext;