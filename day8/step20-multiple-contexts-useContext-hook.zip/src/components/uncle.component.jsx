import { Component } from "react";
import FamilyContext from "../contexts/family.context";

class UncleComp extends Component{
    render(){
        return <div style={ { border : '1px solid grey', padding : '10px', margin : '10px'} }>
                    <h1>Uncle Component</h1>
                    <FamilyContext.Consumer>{  val => <h2>Power : { val }</h2>}</FamilyContext.Consumer>
                </div>
    }
};

export default UncleComp;