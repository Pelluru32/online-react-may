import { useContext } from "react";
import FamilyContext from "../contexts/family.context";
import GenContext from "../contexts/general.context";

let ChildComp = ()=>{
    let power = useContext(FamilyContext);
    let version = useContext(GenContext);
    return <div style={ { border : '1px solid grey', padding : '10px', margin : '10px'} }>
                    <h1>Child Component</h1>
                    {/* <GenContext.Consumer>{  val => <h2>Version : { val }</h2>}</GenContext.Consumer> */}
                    {/* <ul>
                        <FamilyContext.Consumer>{  pow => <li>Power : { pow }</li>}</FamilyContext.Consumer>
                        <FamilyContext.Consumer>{  pow => <li>Power : { pow }</li>}</FamilyContext.Consumer>
                        <FamilyContext.Consumer>{  pow => <li>Power : { pow }</li>}</FamilyContext.Consumer>
                        <FamilyContext.Consumer>{  pow => <li>Power : { pow }</li>}</FamilyContext.Consumer>
                    </ul> */}

                    <h1>Power : { power }</h1>
                    <h2>Version : { version }</h2>
                    <ul>
                        <li>Power : { power }</li>
                        <li>Power : { power }</li>
                        <li>Power : { power }</li>
                        <li>Power : { power }</li>
                    </ul>
                </div>
    }

export default ChildComp;