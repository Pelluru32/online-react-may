import { Component, useState } from "react";
import FamilyContext from "../contexts/family.context";
import GenContext from "../contexts/general.context";
import ParentComp from "./parent.component";
import UncleComp from "./uncle.component";
/* 
class GrandParentComp extends Component{
    state = {
        power : 0,
        version : 0
    }
    render(){
        return <div style={ { border : '1px solid grey', padding : '10px', margin : '10px'} }>
            <h1>Grand Parent Component</h1>
            <button onClick={()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
            <button onClick={()=> this.setState({ version : Math.round( Math.random() * 1000 ) })}>Change Version</button>
            <FamilyContext.Provider value={this.state.power}>
                <GenContext.Provider value={ this.state.version }>
                    <ParentComp/>
                </GenContext.Provider>
                <UncleComp/>
            </FamilyContext.Provider>
        </div>
    }
};
 */


let GrandParentComp= ()=>{
    let [power, setPower] = useState(0);
    let [version, setVersion] = useState(0);
    return <div style={ { border : '1px solid grey', padding : '10px', margin : '10px'} }>
            <h1>Grand Parent Component</h1>
            <button onClick={()=> setPower( power + 1 )}>Increase Power</button>
            <button onClick={()=> setVersion(  Math.round( Math.random() * 1000 ))}>Change Version</button>
            <FamilyContext.Provider value={ power }>
                <GenContext.Provider value={ version }>
                    <ParentComp/>
                </GenContext.Provider>
                <UncleComp/>
            </FamilyContext.Provider>
        </div>
};

export default GrandParentComp;