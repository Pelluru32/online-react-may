let useReverse = (val)=>{
    return val.split('').reverse().join('');
}

export default useReverse;