import { useState } from "react";

let useShowHide =(initVal = false)=>{
    let [state, setState] = useState(initVal)
    let callFun = ()=>{
        setState(!state);
    }
    return [ state, callFun ]
};

export default useShowHide;