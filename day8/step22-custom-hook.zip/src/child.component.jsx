let ChildComp = ()=> {
return  <div>
            <h1>Child Component</h1>
        </div>
};
export default ChildComp;