import ChildComp from "./child.component";
// import useReverse from "./hooks/useReverse";

import { useState } from 'react';
import useShowHide from "./hooks/useShowHide";
let MainApp = ()=> {
    // console.log(useReverse('vijay'));

    // let [show, showHideComp] = useState(true);
    // console.log(useShowHide() ? 'true' : 'false');

    // console.log(useShowHide('hello'));

    let [state, updateState] = useShowHide();

    return  <div className="container">
            <h1>Using useEffect Hook</h1>
            <h2>{ state ? 'true' : 'false'}</h2>
            {/* <h3>{ message ? 'true' : 'false' }</h3> */}
            <button onClick={ ()=> updateState() }>Show / Hide</button>
            { state && <ChildComp/> }
                
            </div>
    };
    export default MainApp;