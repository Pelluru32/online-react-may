import { useReducer, useState } from "react";

let MainApp = ()=> {
   // let [state, dispatch] = useReducer( reducer, initialstate );
   

   // pure function
   let reducer = (heroinfo, action)=>{
    switch(action.type){
        case "CHANGEFIRSTNAME" : return { ...heroinfo, firstname : action.val }
        case "CHANGELASTNAME" : return { ...heroinfo, lastname : action.val }
        case "CHANGEPOWER" : return { ...heroinfo, power : action.val }
        case "CHANGECITY" : return { ...heroinfo, city : action.val }
        default : return heroinfo
    }
   }
   let [state, dispatch] = useReducer( reducer, { firstname : '', lastname : '', power : 0, city :'' } );


return  <div className="container">
            <h1>Using Hooks</h1>
            <hr />

            <div className="mb-2">
                <label htmlFor="fname">First Name</label>
                <input value={state.firstname} onChange={(evt)=>dispatch({ val: evt.target.value,  type: "CHANGEFIRSTNAME" })}  id="fname" type="text" />
            </div>
            <div className="mb-2">
                <label htmlFor="lname">Last Name</label>
                <input value={state.lastname} onChange={(evt)=>dispatch({ val: evt.target.value,  type: "CHANGELASTNAME" })}  id="lname" type="text" />
            </div>
            <div className="mb-2">
                <label htmlFor="hpower">Power</label>
                <input value={state.power} onChange={(evt)=>dispatch({ val: evt.target.value,  type: "CHANGEPOWER" })}  id="hpower" type="range" />
            </div>
            <div className="mb-2">
                <label htmlFor="hcity">City</label>
                <input value={state.city} onChange={(evt)=>dispatch({ val: evt.target.value,  type: "CHANGECITY" })}  id="hcity" type="text" />
            </div>
            <ul>
                <li>First Name { state.firstname }</li>
                <li>Last Name { state.lastname }</li>
                <li>Full Name { state.firstname+" "+state.lastname }</li>
                <li>Power { state.power }</li>
                <li>City { state.city }</li>
            </ul>
        </div>
};
export default MainApp;