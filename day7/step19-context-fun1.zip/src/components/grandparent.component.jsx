import { Component } from "react";
import FamilyContext from "../contexts/family.context";
import ParentComp from "./parent.component";

class GrandParentComp extends Component{
    state = {
        power : 0
    }
    render(){
        return <div style={ { border : '1px solid grey', padding : '10px', margin : '10px'} }>
            <h1>Grand Parent Component</h1>
            <button onClick={()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
            <FamilyContext.Provider value={this.state.power}>
                <ParentComp/>
            </FamilyContext.Provider>
        </div>
    }
};

export default GrandParentComp;