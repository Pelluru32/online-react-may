import React from 'react';
// Provider value
// Consumer calls a function that gets the value

let FamilyContext = React.createContext();

export default FamilyContext;