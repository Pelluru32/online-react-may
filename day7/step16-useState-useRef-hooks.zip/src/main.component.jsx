import React, { useRef, useState } from "react";

export let MainApp = ()=> {
   // console.log(  useState() );
   let [power, setPower] = useState(0);
   let [avengers, addAvenger] = useState([]);
   let [userInfo, setUserInfo] = useState({ firstname: '', lastname : ''});
   // let avengerInput = React.createRef();
   let avengerInput = useRef();
    return <div className="container"> 
                <h1>Working with Function based components</h1>
                <h2>Power : { power }</h2>
                <button onClick={ ()=> setPower(power+1) }>Increase Power</button>
                <hr />
                <div className="mb-3">
                    <label className="form-label" htmlFor="uFirstName">User First Name</label>
                    <input onChange={(evt)=> setUserInfo({...userInfo, firstname : evt.target.value }) } value={userInfo.firstname} className="form-control" id="uFirstName" type="text" />
                </div>
                <div className="mb-3">
                    <label className="form-label" htmlFor="uLastName">User Last Name</label>
                    <input onChange={(evt)=> setUserInfo({...userInfo, lastname : evt.target.value }) } value={userInfo.lastname} className="form-control" id="uLastName" type="text" />
                </div>
                <ul>
                    <li>First Name : { userInfo.firstname }</li>
                    <li>Last Name : { userInfo.lastname }</li>
                </ul>
                <hr />
                <div className="mb-3">
                    <label className="form-label" htmlFor="avenger">Add Avenger</label>
                    <input ref={avengerInput} className="form-control" id="avenger" type="text" />
                </div>
                <button onClick={()=>addAvenger([...avengers, avengerInput.current.value ])}>Add Avenger</button>
                <ul>
                   { avengers.map((val, idx) => <li key={idx}>{ val }</li>)}
                </ul>
            </div>
};
