import { useEffect } from "react";

let ChildComponent = ({ver})=> {
   /*  */ 
   
    useEffect(()=>{
        console.log("child component was rendered");
    },[]);
    useEffect(()=>{
        console.log("child component's ver was updated to ", ver);
    },[ver]);
    useEffect(()=>{
       return ()=>{
        console.log("child component's is unmounted");
       }
    },[]);

   /*  useEffect(()=>{
        console.log("child component was mounted");
        console.log("child component's ver was updated to ", ver);
        return ()=>{
            console.log("child component's is unmounted");
           }
    },[ver]); */

  
    return  <div>
                <h2>Version is : { ver }</h2>
            </div>
};
export default ChildComponent;