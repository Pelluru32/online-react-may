import { useState } from "react";
import ChildComponent from "./child.component";

let MainApp = ()=> {
    // console.log("MainApp was rendered")
    let [version, setVersion] = useState(0)
    return  <div className="container">
                <h1>Using useEffect Hook</h1>
                <button className="btn btn-primary" onClick={()=> setVersion(version+1)}>Increase Version</button>
                { version < 10 && <ChildComponent ver={ version }/> }
            </div>
};
export default MainApp;