import { useEffect, useState } from "react";
import axios from "axios";


let ChildComponent = ({ver})=> {
    let [users, setUsers] = useState([]);
    let [error, setError] = useState('');
    let loadData = ()=>{
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then(res=>setUsers(res.data))
        .catch(error=>setError(error.message));
    }
    useEffect(()=>{
        console.log("child component was rendered");
        loadData();
    },[]);
    useEffect(()=>{
        console.log("child component's ver was updated to ", ver);
    },[ver]);
    useEffect(()=>{
       return ()=>{
        console.log("child component's is unmounted");
       }
    },[]);

   /*  useEffect(()=>{
        console.log("child component was mounted");
        console.log("child component's ver was updated to ", ver);
        return ()=>{
            console.log("child component's is unmounted");
           }
    },[ver]); */

    return  <div>
                <h2>Version is : { ver }</h2>
                <ol>{ users.map(val=><li key={val.id}>{ val.name }</li>) }</ol>
                { error && <p className="text-danger">{ error }</p>}
            </div>
};
export default ChildComponent;