import React, { Component } from "react";

class MainApp extends Component{
    state = {
        username : '',
        usercity : '',
        userage : 0,
        showNameError : false,
        showCityError : false,
        showAgeError : false
    }
    log = React.createRef();
    /*     
    userNameChangeHandler = (evt)=>{
        this.setState({ username : evt.target.value })
    }
    userCityChangeHandler = (evt)=>{
        this.setState({ usercity : evt.target.value })
    }
    userAgeChangeHandler = (evt)=>{
        this.setState({ userage : evt.target.value })
    } 
    */
    changeHandler = (evt)=>{
        this.setState({ [evt.target.id] : evt.target.value })
    }
    onSubmitHandler = (evt)=>{
        evt.preventDefault();
        // alert("form submitted")
        if(this.state.username && this.state.usercity && this.state.userage !== 0){
            if(this.state.userage < 18){
                    alert("you are too young to join us")
            }else if( this.state.userage > 90){
                    alert("you are too old to join us")
            }else{
                evt.target.submit();
                this.setState({
                    showNameError : false,
                    showCityError : false,
                    showAgeError : false
                });
               /*  this.log.current.innerHTML = `
                    <p>User Name : ${ this.state.username }</p>
                    <p>User City : ${ this.state.usercity }</p>
                    <p>User Age : ${ this.state.userage }</p>
                ` */
            }
        }else{
            this.setState({
                showNameError : true,
                showCityError : true,
                showAgeError : true
            })
        }
    }
    render(){
        return <div className="container">
            <h1>React Form</h1>
                    <form onSubmit={ this.onSubmitHandler } >
                        <div className="mb-3">
                            <label htmlFor="username" className="form-label">User Name</label>
                            <input name="username" value={this.state.username} onChange={this.changeHandler } id="username" type="text" className="form-control" />
                            { this.state.showNameError && <div className="form-text text-danger">User Name is Required</div>}

                            <label htmlFor="usercity" className="form-label">User City</label>
                            <input name="usercity" value={this.state.usercity} onChange={this.changeHandler } id="usercity" type="text" className="form-control" />
                            { this.state.showCityError && <div className="form-text text-danger">User City is Required</div> }

                            <label htmlFor="userage" className="form-label">User Age</label>
                            <input name="userage" value={this.state.userage} onChange={this.changeHandler } id="userage" type="number" className="form-control" />
                            { this.state.showAgeError && <div className="form-text text-danger">User Age is Required</div> }
                        </div>
                        <button type="submit" className="btn btn-primary">Submit</button>
                    </form>
                    <hr />
                   {/*  <ul>
                        <li>User Name : { this.state.username }</li>
                        <li>User City : { this.state.usercity }</li>
                        <li>User Age : { this.state.userage }</li>
                    </ul> */}
                     <ul>
                        <li>User Name : { this.state.username }</li>
                        <li>User City : { this.state.usercity }</li>
                        <li>User Age : { this.state.userage }</li>
                    </ul>
                    <div ref={this.log}></div>
               </div>
    }
};

export default MainApp;