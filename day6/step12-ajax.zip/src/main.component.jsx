import { Component } from "react";
import axios from "axios";

class MainApp extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        // ajax call
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then(res => this.setState({
            users : res.data
        },()=>{
            console.log( this.state.users )
        }))
        .catch( error => console.log("Error ", error))
    }
    render(){
        return <div>
            <ul>{ this.state.users.map( val => <li key={val.id}>{ val.name }</li> ) }</ul>
        </div>
    }
};

export default MainApp;


// CRUD