import React from "react";

let FunMemoComp = (props) => {
    console.log("FunMemoComp's render was called", Math.random());
    return <div>
            <h2>Function Memo Component</h2>
            <ul>
                <li>Power is { props.power }</li>
                <li>Version is { props.version }</li>
            </ul>
        </div>
};

export default React.memo( FunMemoComp );