import {  PureComponent } from "react";

class PureClassComp extends PureComponent{
    render(){
        console.log("PureClassComp's render was called", Math.random());
        return <div>
                <h2>Pure Class Component</h2>
                <ul>
                    <li>Power is { this.props.power }</li>
                    <li>Version is { this.props.version }</li>
                </ul>
              </div>
    }
}

export default PureClassComp;