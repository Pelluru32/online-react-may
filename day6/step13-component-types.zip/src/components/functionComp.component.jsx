let FunComp = (props) => {
    console.log("FunComp's render was called", Math.random());
    return <div>
            <h2>Function Component</h2>
            <ul>
                <li>Power is { props.power }</li>
                <li>Version is { props.version }</li>
            </ul>
        </div>
};

export default FunComp;