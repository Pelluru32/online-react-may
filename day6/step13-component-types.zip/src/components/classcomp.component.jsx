import { Component } from "react";

class ClassComp extends Component{
    render(){
        console.log("ClassComp's render was called", Math.random());
        return <div>
                <h2>Class Component</h2>
                <ul>
                    <li>Power is { this.props.power }</li>
                    <li>Version is { this.props.version }</li>
                </ul>
              </div>
    }
}

export default ClassComp;