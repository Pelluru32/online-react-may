import { Component } from "react";
import ClassComp from "./components/classcomp.component";
import FunMemoComp from "./components/function.memo.component";
import FunComp from "./components/functionComp.component";
import PureClassComp from "./components/pureComp.component";

class MainApp extends Component{
    state = {
        power : 0,
        version : 0
    }
    changePower = ()=>{
        this.setState({
            power : Math.round(Math.random() * 1000)
        })
    }
    changeVersion = ()=>{
        this.setState({
            version : 1001
        })
    }
    render(){
        return <div>
                    <h1>Component Types</h1>
                    <button onClick={ this.changePower }>Change Power</button>
                    <button onClick={ this.changeVersion }>Change Version</button>
                    <hr/>
                    <ClassComp power={ this.state.power } version={ this.state.version }/>
                    <PureClassComp power={ this.state.power } version={ this.state.version }/>
                    <FunComp power={ this.state.power } version={ this.state.version } />
                    <FunMemoComp power={ this.state.power } version={ this.state.version } />
               </div>
    }
};

export default MainApp;