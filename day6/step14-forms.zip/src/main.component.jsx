import { Component } from "react";

class MainApp extends Component{
    render(){
        return <div className="container">
                    <form>
                        <div className="mb-3">
                            <label htmlFor="userName" className="form-label">User Name</label>
                            <input type="text" className="form-control" />
                            <div className="form-text">User Name is Required</div>

                            <label htmlFor="userCity" className="form-label">User City</label>
                            <input type="text" className="form-control" />
                            <div className="form-text">User City is Required</div>

                            <label htmlFor="userAge" className="form-label">User Age</label>
                            <input type="number" className="form-control" />
                            <div className="form-text">User Age is Required</div>
                        </div>
                        <button type="submit" className="btn btn-primary">Submit</button>
                    </form>
               </div>
    }
};

export default MainApp;