import { Component } from "react";
import ChildComp from "./child.component";

class MainApp extends Component{
    state = {
        mainAppPower : 1
    }
    render(){
        return <div>
                    <h1>Main Component | mainAppPower : { this.state.mainAppPower }</h1>
                    <button onClick={()=> this.setState({ mainAppPower : this.state.mainAppPower+1 })}>Increase Power</button>
                    <button onClick={()=> this.setState({ mainAppPower : this.state.mainAppPower-1 })}>Decrease Power</button>
                    <ChildComp power={ this.state.mainAppPower }/>
               </div>
    }
};

export default MainApp;