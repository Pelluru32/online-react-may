import { Component } from "react";

class ChildComp extends Component{
    state = {
        childPower : 0
    }
    changes = [];
    constructor(){
        super();
        this.state.childPower = 10;
        console.log("Child Component's constructor was called")
    }
    // derive the state of the component from props
    static getDerivedStateFromProps(compProps, compState){
        // console.log(compProps, compState)
        console.log("Child Component's getDerivedStateFromProps was called");
        return {
            childPower : compProps.power * 10
        } 
    }
    componentDidMount(){
        // useful to subscribe ajax calls
        console.log("Child Component's componentDidMount was called")
    }
    shouldComponentUpdate(compProps, compState){
        console.log("Child Component's shouldComponentUpdate was called")
        /* if(this.state.childPower < compProps.power){
            return true
        }else{
            return false
        } */
        return true
    }
    getSnapshotBeforeUpdate(compProps, compState){
        console.log("Child Component's getSnapshotBeforeUpdate was called")
        return {
            currentStatePower : compState.childPower,
            currentPropPower : compProps.power
        }
    }
    componentDidUpdate(compProps, compState, snapShot){
        console.log(arguments.length);
        // console.log(args[0], args[1], args[2]);
        console.log("Child Component's componentDidUpdate was called");
        this.changes.push({
            currentProps : compProps,
            currentState : compState,
            prevVals : snapShot
        });
        console.log(this.changes);
    }
    componentWillUnmount(){
        // useful to unsubscribe ajax calls
        console.log("Child Component's componentWillUnmount was called")
    }
    render(){
        console.log("Child Component's render was called")
        return <div>
                    <h2>Child Component | Power : { this.state.childPower }</h2>
               </div>
    }
};

export default ChildComp;

/*

Mounting
--------
These methods are called in the following order when an instance of a component is being created and inserted into the DOM:
    constructor()
    static getDerivedStateFromProps()
    render()
    componentDidMount()
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Updating
--------
An update can be caused by changes to props or state. These methods are called in the following order when a component is being re-rendered:
    static getDerivedStateFromProps()
    shouldComponentUpdate()
    render()
    getSnapshotBeforeUpdate()
    componentDidUpdate()

Unmounting
----------
This method is called when a component is being removed from the DOM:
    componentWillUnmount()
*/