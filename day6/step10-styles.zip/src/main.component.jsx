import { Component } from "react";
import mystyle from "./external.style";
import myclient from "./company.module.css";
import "./mycompstyle.css";

class MainApp extends Component{

    myincompstyle =  { 
        backgroundColor :  'orange', 
        padding : '10px', 
        margin : '10px', 
        color : 'white' 
    }

    render(){
        return <div>
                <h1>Styles in React</h1>
                <p style={ { backgroundColor :  'red', padding : '10px', margin : '10px' } }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias ratione consequatur, unde architecto quo aliquam praesentium, necessitatibus vitae eos ad delectus quam dolorem dicta maxime incidunt iusto nisi ipsam. Optio!
                </p>
                <p style={ this.myincompstyle }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, ad? Veniam asperiores nam eaque molestias suscipit temporibus numquam animi vitae itaque voluptatibus aliquid non voluptas illo, delectus officiis expedita dignissimos.
                </p>
                <p style={ mystyle }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, ad? Veniam asperiores nam eaque molestias suscipit temporibus numquam animi vitae itaque voluptatibus aliquid non voluptas illo, delectus officiis expedita dignissimos.
                </p>
                <p style={ {...mystyle,  backgroundColor :  'darkslateblue'} }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid et deleniti amet quisquam quia expedita libero omnis odio necessitatibus fugiat voluptatum repudiandae, saepe magni consequuntur, tempore ipsum, debitis cupiditate placeat?
                </p>
                <hr />
                <div className="box">
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Libero, corporis ut quisquam consequuntur illo, debitis tempore consectetur molestiae alias vero voluptatum. Nisi possimus unde sit dignissimos blanditiis hic eius? Consectetur.
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Libero, corporis ut quisquam consequuntur illo, debitis tempore consectetur molestiae alias vero voluptatum. Nisi possimus unde sit dignissimos blanditiis hic eius? Consectetur.
                </div>
                <div className={myclient.box}>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Libero, corporis ut quisquam consequuntur illo, debitis tempore consectetur molestiae alias vero voluptatum. Nisi possimus unde sit dignissimos blanditiis hic eius? Consectetur.
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Libero, corporis ut quisquam consequuntur illo, debitis tempore consectetur molestiae alias vero voluptatum. Nisi possimus unde sit dignissimos blanditiis hic eius? Consectetur.
                </div>
               </div>
    }
};

export default MainApp;

/*
scss
sass
*/