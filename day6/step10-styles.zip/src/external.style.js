let mystyle =  { 
    backgroundColor :  'crimson', 
    padding : '10px', 
    margin : '10px', 
    color : 'white' 
}

export default mystyle;