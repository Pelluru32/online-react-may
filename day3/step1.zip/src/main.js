/* 
let elm = <h1>Welcome to your life</h1>;

export default elm; 
*/

let MainApp = function(){
    return <h1>Welcome to your life</h1>
};

export default MainApp;