let express = require("express");
let mongoose = require("mongoose");
let cors = require("cors");
let config = require("./config.json");
//-------------------------------
let app = express();
app.use(express.json());// middleware
app.use(cors());
//---------------------------------
// configurations for database
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Hero = mongoose.model("Hero", new Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String,
    power : Number,
    city : String
}));
mongoose.connect(config.url.replace("<username>", config.username).replace("<password>",config.password))
.then(res => console.log("Database is now connected"))
.catch(error => console.log("Error",error));
//---------------------------------
// configurations for routes
// READ // http://localhost:5050/data
app.get("/data",(req, res)=>{
    Hero.find((error, heroeslist)=>{
        if(error){ console.log("Error", error)}
        else{ res.json(heroeslist); }
    })
})
// CREATE
app.post("/data",(req, res)=>{
    let hero = new Hero(req.body);
    console.log(req.body)
    hero.save()
    .then(dbres => res.send({ "message": "Hero was added" }))
    .catch(error=> console.log("Error", error))
}) 

// READ BEFORE UPDATE
app.get("/edit/:hid", (req, res)=>{
    Hero.findById(req.params.hid, (error, hero)=>{
        if(error){ console.log("Error", error)}
        else{ res.json(hero) }
    })
});
// UPDATE
app.post("/edit/:hid", (req, res)=>{
    Hero.findById(req.params.hid, (error, hero)=>{
        if(error){ console.log("Error", error)}
        else{ 
            hero.title = req.body.title;
            hero.firstname = req.body.firstname;
            hero.lastname = req.body.lastname;
            hero.city = req.body.city;
            hero.power = req.body.power;
            hero.save()
            .then( dbres=> res.json(dbres))
            .catch( error => console.log("Error", error))
        }
    })
});

// DELETE
app.delete("/delete/:hid", (req, res)=>{
    Hero.findByIdAndDelete(req.params.hid, (error, dbRes)=>{
        if(error){ console.log("Error", error)}
        else{ res.json({ "message" : JSON.stringify(dbRes) })}
    })
})
//---------------------------------
// configurations for web server
app.listen(5050, "localhost");
console.log("server is now running on localhost:5050");