import { useParams } from "react-router-dom";

let SupermanComp = ()=> {
    let myparams = useParams();
    return  <div>
                <h2>Superman Component</h2>
                <h3> Quantity is { myparams.qty || 0 }</h3>
            </div>
    };
    export default SupermanComp;