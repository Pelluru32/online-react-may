import { BrowserRouter,Route, Routes, Navigate, NavLink } from "react-router-dom";

import HomeComp from "./home.component";
import "./mystyle.css";
import React, { useState, Suspense } from "react";

let MainApp = ()=> {
  let [power, setPower] = useState(0);
  let BatmanComp = React.lazy(()=> import("./batman.component"));
  let AquamanComp = React.lazy(()=> import("./aquaman.component"));
  let NotFoundComp = React.lazy(()=> import("./notfound.component"));
  let SupermanComp = React.lazy(()=> import("./superman.component"));

return  <div className="container">
            <h1>Using Routes</h1>
            <h2>Power is : { power }</h2>
            <button onClick={()=>setPower(power+1)}>Increase Power</button>
            <BrowserRouter>
                <ul>
                    <li><NavLink className={({isActive})=> isActive ? 'boxer' : null} to="/">Home </NavLink></li>
                    <li><NavLink className={({isActive})=> isActive ? 'boxer' : null} to="/batman/movies">Batman</NavLink></li>
                    <li><NavLink className={({isActive})=> isActive ? 'boxer' : null} to={'/superman/'+power}>Superman</NavLink></li>
                    <li><NavLink className={({isActive})=> isActive ? 'boxer' : null} to="/aquaman">Aquaman</NavLink></li>
                    <li><NavLink className={({isActive})=> isActive ? 'boxer' : null} to="/flash">Flash</NavLink></li>
                    <li><NavLink className={({isActive})=> isActive ? 'boxer' : null} to="/hulk">Hulk</NavLink></li>
                </ul>
                <Routes>
                    <Route path="/" element={<HomeComp/>} /> {/* Default Route */}
                    <Route path="/batman" element={<Suspense fallback={<>Loading...</>}><BatmanComp/></Suspense>} /> {/* Named Route */}
                    <Route path="/superman/" element={ <Suspense fallback={<>Loading...</>}><SupermanComp/></Suspense>  } >
                        <Route path=":qty" element={ <Suspense fallback={<>Loading...</>}><SupermanComp/></Suspense> } />    
                    </Route> {/* Named Route */}
                    <Route path="/aquaman" element={<Suspense fallback={<>Loading...</>}><AquamanComp/></Suspense>} /> {/* Named Route */}
                    <Route path="/flash" element={<Navigate to={"/batman"} replace  />} /> {/* Route Redirection */}
                    <Route path="*" element={ <Suspense fallback={<>Loading...</>}><NotFoundComp/></Suspense> } />{/* Catch All Route */}
                </Routes>
            </BrowserRouter>
        </div>
};
export default MainApp;
