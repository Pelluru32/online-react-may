let NotFoundComp = ()=> {
    return  <div>
                <h2>404 | File Not Found Component</h2>
            </div>
    };
    export default NotFoundComp;