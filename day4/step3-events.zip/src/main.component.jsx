import React, { Component } from "react";

class MainApp extends Component{
    state = {
        power : 0
    }
    numIp = React.createRef();

    render(){
        return <div>
                    <h1>Power : { this.state.power }</h1>
                    <button onClick={ this.clickToIncrease }>Increase Power</button>
                    <input type="range" onInput={ this.slideToIncrease } />
                    <hr />
                    <input ref={ this.numIp } type="number" />
                    <button onClick={ this.setPowerFromNumber  }>Click to Set Power from Number</button>
               </div>
    }
    clickToIncrease = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    } 

    slideToIncrease = (evt)=>{
        this.setState({
            power : Number(evt.target.value)
        })
    }
    
    setPowerFromNumber = ()=>{
        console.log(this.numIp);
        this.setState({
            power : Number(this.numIp.current.value)
        })
    }
};

export default MainApp;