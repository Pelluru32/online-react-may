import { createRoot } from "react-dom/client";
import MainApp from "./main.component";

createRoot(document.getElementById("root")).render(<MainApp/>)