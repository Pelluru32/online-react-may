import { Component } from "react";

class Article extends Component{
    render(){
        return <div>
                <h3>{ this.props.version }</h3>
                <h3>Power is :{ this.props.power }</h3>
                { this.props.children }
               </div>
    }
}

class MainApp extends Component{
    render(){
        return <div>
                <h1>Welcome to your life</h1>
                <Article power="preparing" version="101">
                    Article 1
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime, minima itaque explicabo autem obcaecati ut accusamus labore suscipit, reiciendis earum similique eos accusantium? Expedita reprehenderit libero quasi deleniti blanditiis quibusdam!
                </Article>
                <Article power="ready" version="102">
                    <ul>
                        <li>List Item 1</li>
                        <li>List Item 2</li>
                        <li>List Item 3</li>
                    </ul>
                </Article>
                <Article power="strong" version="103">
                    <button>Click Me</button>
                </Article>
               </div>
    }
};

export default MainApp;