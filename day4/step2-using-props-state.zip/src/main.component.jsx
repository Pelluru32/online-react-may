import { Component } from "react";

class HeroList extends Component{
   /*  constructor(){
        super();
        this.clickHandler = this.clickHandler.bind(this)
    } */
    render(){
        return <div>
                    <h2>{ this.props.title }</h2>
                    <h2>Version : { this.props.version }</h2>
                    <ul>{ this.props.list.map( (val, idx) => <li key={ idx }>{ val }</li>) }</ul>
                    {/* <button onClick={ this.clickHandler.bind(this) }>Change Version</button> */}
                    <button onClick={ this.clickHandler }>Change Version</button>
                    <button onClick={ this.clickHandler }>Change Version</button>
                    <button onClick={ this.clickHandler }>Change Version</button>
                    <button onClick={ this.clickHandler }>Change Version</button>
                    <button onClick={ this.clickHandler }>Change Version</button>
               </div>
    }
    clickHandler = () => {
        // alert(this.props.version);
        this.props.version = this.props.version+1;
    }
}

class MainApp extends Component{
    avengers = ['Ironman','Antman','Spiderman','Scarlet', 'Black Widow'];
    justiceleague = ['Batman',"Superman","Aquaman","Flash","Wonder Women"];
    state = {
        compVersion : 101
    }
    render(){
        return <div>
                    <h3>{ this.state.compVersion }</h3>
                    <button onClick={ this.changeVersionHandler }>Change Version</button>
                    <hr />
                    <HeroList version={this.state.compVersion} title="Avengers" list={ this.avengers }/>
                    <HeroList version={this.state.compVersion} title="Justice League" list={ this.justiceleague }/>
                </div>
    }
    changeVersionHandler = ()=>{
        // console.log(this.compVersion);
        // this.forceUpdate();
        /*         
        this.compVersion = this.compVersion+1;
        console.log(this.compVersion); 
        */
        this.setState({
            compVersion : this.state.compVersion + 1
        })
    }
};

export default MainApp;