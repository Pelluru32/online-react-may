import ADD_HERO from "../types/hero.type"

let addHero = function(){
    return {
        type : ADD_HERO
    }
}

export default addHero;