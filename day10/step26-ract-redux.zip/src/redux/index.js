import addHero from "./hero/actioncreators/hero.action";
export default addHero ;