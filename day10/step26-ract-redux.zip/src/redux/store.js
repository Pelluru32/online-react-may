import { createStore } from "redux";
import heroReducer from "./hero/reducer/hero.reducer";
const store = createStore(heroReducer);

export default store;