import { Component } from "react";
import MirrorComp from "./mirror.component";

class MirrorParentApp extends Component{
    render(){
        return <div>
                    <h3>Mirror Parent Component App</h3>
                    <MirrorComp/>
                </div>
    }
};

export default MirrorParentApp;
