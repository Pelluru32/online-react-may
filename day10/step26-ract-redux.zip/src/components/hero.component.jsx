import { Component } from "react";
import { connect } from "react-redux";
import addHero from "../redux";

class HeroComp extends Component{
    render(){
        return <div>
                <h1>Avengers Enrollment Program</h1>
                <h2>Number of Heroes : { this.props.numberOfHeroes }</h2>
                <button onClick={ this.props.addHero }>Add Hero</button>
               </div>
    }
};
let mapStateToProps = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}
let mapDispatchToProps = (dispatch)=>{
    return {
        addHero : ()=> dispatch( addHero() )
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(HeroComp);
