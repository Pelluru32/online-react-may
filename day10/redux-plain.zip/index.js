// action : is an object that has type and payload
// action creator is function that returns an action object
// create an inital state
// reducer : is a function that takes state and action as parameters and returns an object based on action type
// store : can store state of your application, you can subscribe and unsubscribe to watch for changes

let redux = require("redux");
let createStore = redux.createStore;
let combineReducers = redux.combineReducers;
// action
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";

const ADD_MOVIE = "ADD_MOVIE";
const REMOVE_MOVIE = "REMOVE_MOVIE";

// action creator
let addHero = ()=>{
    return {
        type : ADD_HERO
    }
};
let removeHero = ()=>{
    return {
        type : REMOVE_HERO
    }
};
let addMovie = ()=>{
    return {
        type : ADD_MOVIE
    }
};
let removeMovie = ()=>{
    return {
        type : REMOVE_MOVIE
    }
};

// initial state
let initialHeroState = {
    numberOfHeroes : 0
};
// initial state
let initialMovieState = {
    numberOfMovies : 0
};

// reducer
let heroReducer = function(state = initialHeroState, action){
    switch(action.type){
        case ADD_HERO : return {...state, numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVE_HERO : return {...state, numberOfHeroes : state.numberOfHeroes - 1 }
        default : return state
    }
}
let movieReducer = function(state = initialMovieState, action){
    switch(action.type){
        case ADD_MOVIE : return {...state, numberOfMovies : state.numberOfMovies + 1 }
        case REMOVE_MOVIE : return {...state, numberOfMovies : state.numberOfMovies - 1 }
        default : return state
    }
}

let rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})
const store = createStore(rootReducer);

let unsubscribe = store.subscribe(()=> console.log("State Changes After Subscription : ",store.getState()));

console.log("Initial State of Store ",store.getState());

store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( removeHero() );
store.dispatch( removeHero() );
store.dispatch( removeHero() );
store.dispatch( removeHero() );
store.dispatch( addMovie() );
store.dispatch( addMovie() );
store.dispatch( addMovie() );
store.dispatch( addMovie() );
store.dispatch( addMovie() );
store.dispatch( addMovie() );
store.dispatch( addMovie() );
store.dispatch( removeMovie() );
store.dispatch( removeMovie() );
store.dispatch( removeMovie() );
store.dispatch( removeMovie() );

unsubscribe();

console.log("unsubscribed");