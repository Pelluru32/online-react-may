import ADD_HERO from "../types/hero.type"

let initialHeroState = {
    numberOfHeroes : 0
}

let heroReducer = (state = initialHeroState, action)=>{
    switch(action.type){
        case ADD_HERO : return {...state, numberOfHeroes : state.numberOfHeroes + 1 } 
        default : return state
    }
}

export default heroReducer;