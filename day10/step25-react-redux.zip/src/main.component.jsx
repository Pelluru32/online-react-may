import { Provider } from "react-redux";
import HeroComp from "./components/hero.component";
import MirrorParentApp from "./components/mirror.parent.component";
import store from "./redux/store";
let MainApp = ()=> {
    return  <div className="container">
                <h1>Using react redux</h1>
                <Provider store={ store }>
                    <HeroComp/>
                    <MirrorParentApp/>
                </Provider>
            </div>
    };
    export default MainApp;