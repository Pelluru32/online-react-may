import { Component } from "react";
import ChildComp from "./child.component";

class MainApp extends Component{
    state = {
        title : 'MainApp Title',
        version : 1
    }
    render(){
        return <div>
                    <h1>Prop Types</h1>
                    <hr />
                    <ChildComp ver={ this.state.version } title={ this.state.title }/>
                    <ChildComp ver={ this.state.version }  title={ this.state.title }/>
                    <ChildComp title={ this.state.title } ver={ this.state.version } />
                    <ChildComp title={ this.state.title } ver={ this.state.version } />
               </div>
    }
};

export default MainApp;