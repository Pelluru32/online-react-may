import { Component } from "react";
import PropTypes from 'prop-types';

class ChildComp extends Component{
    static propTypes = {
        title : PropTypes.string.isRequired,
        ver : PropTypes.number.isRequired
    }
    render(){
        return <div>
            <h2>Child Component</h2>
            <ul>
                <li>Version : { this.props.ver * 10 }</li>
                <li>Title : { this.props.title.toUpperCase() }</li>
            </ul>
        </div>
    }
};

export default ChildComp;