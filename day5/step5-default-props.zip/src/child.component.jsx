import { Component } from "react";

class ChildComp extends Component{
   /*  static defaultProps = {
        ver : 100,
        title : 'child title'
    } */
    render(){
        return <div style={ {  border : '2px solid red', margin : '10px', padding : '10px' } }>
                    <h2>Child Component</h2>
                    <h3>Version is : { this.props.ver  }</h3>
                    <h3>Title is : { this.props.title  }</h3>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, id. Quasi reprehenderit dolore laborum ab unde? Accusantium, ullam dignissimos. Cupiditate blanditiis dolorem libero maiores, maxime sed minima optio pariatur eligendi?
                    </p>
               </div>
    }
}

ChildComp.defaultProps = {
        ver : 100,
        title : 'child title'
};

export default ChildComp;