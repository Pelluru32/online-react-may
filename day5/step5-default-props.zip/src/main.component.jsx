import { Component } from "react";
import ChildComp from "./child.component";

class MainApp extends Component{
    state = {
        version : 0,
        title : 'default title'
    }
    render(){
        return <div>
                    <h1>Props and PropTypes : { this.state.version }</h1>
                    <button onClick={ this.increaseVersionHandler }>Increase Version</button>
                    <button onClick={ ()=> this.setState({ title : 'changed' })}>Change Title</button>
                    <hr />
                    <ChildComp title={ this.state.title } ver={this.state.version}/>
                    <ChildComp ver={this.state.version}/>
                    <ChildComp title={ this.state.title }/>
                    <ChildComp/>
               </div>
    }

    increaseVersionHandler = ()=>{
        this.setState({
            version : this.state.version + 1
        })
    }
};

export default MainApp;