import { Component } from "react";

class MainApp extends Component{
    state = {
        power : 0
    }
    render(){
        return <div>
                    <h1>Power is { this.state.power }</h1>
                    <button onClick={ this.increaseHandler }>Increase Power</button>
               </div>
    }
    increaseHandler = ()=>{
       /*  this.setState({
            power : this.state.power + 1
        });
        console.log('Power is ',this.state.power); */
        /*         
        this.setState({
            power : this.state.power + 1
        }, function(){
            console.log('Power is ',this.state.power); 
        }); 
        */
        this.setState(function(currentState, currentProps){
           // console.log(args[0], args[1]);
           return {
               power : currentState.power + 1
           }
        }, function(){
            console.log('Power is ',this.state.power); 
        });
    }
};

export default MainApp;