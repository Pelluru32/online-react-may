import React, { Component } from "react";

class ChildComp extends Component{
    render(){
        return <div>
                  <h2>Child Component</h2>
                  <h3>Power is : { this.props.power } </h3>
                  <h3>Message is : { this.props.message } </h3>
                  <button onClick={ this.props.incPower }>Increase Power</button>
                  <button onClick={ this.props.decPower }>Decrease Power</button>
                  <br />
                  <button onClick={()=> this.props.childMessage('hello from Child')}>Change Message of Parent</button>
               </div>
    }
}

export default ChildComp


// to render multiple root tags you can use React.Fragment or <>