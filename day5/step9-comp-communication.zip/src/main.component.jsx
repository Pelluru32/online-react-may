import React, { Component } from "react";
import ChildComp from "./child.component";

class MainApp extends Component{
    txtRef = React.createRef();
    state = {
        power : 1,
        message : ''
    }
    render(){
        return <div>
                <h2>Parent Component </h2>
                <h3>Power : { this.state.power }</h3>
                <h3>Message : { this.state.message }</h3>
                <input ref={ this.txtRef } type="text" onInput={()=> this.setState({ message : this.txtRef.current.value })} />
                <hr />
                    <ChildComp  incPower={this.increasePower} 
                                decPower={ this.decreasePower } 
                                childMessage={ this.changeMessageHandler }
                                message={ this.state.message } 
                                power={ this.state.power }/>
                </div>
    }
    increasePower = ()=> this.setState({ power : this.state.power + 1});
    decreasePower = ()=> this.setState({ power : this.state.power - 1});
    changeMessageHandler = (nmessage)=> this.setState({ message : nmessage});
};

export default MainApp;