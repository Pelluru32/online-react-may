import { Component } from "react";

class MainApp extends Component{
    state = {
        power : 0,
        name : "Main App"
    }
    /*     
    constructor(){
        super();
        this.clickHandler = this.clickHandler.bind(this);
    } 
    */
    render(){
        return <div>
                <h1>Events in React</h1>
                <h2>Power : { this.state.power }</h2>
               {/*  <button onClick={ this.clickHandler.bind(this) }>Click Me</button> */}
                <button onClick={ this.clickHandler }>Click Me</button>
                <button onClick={ this.clickHandler }>Click Me</button>
                <button onClick={ this.clickHandler }>Click Me</button>
                <button onClick={ this.clickHandler }>Click Me</button>
                <button onClick={ ()=>  this.setPowerHandler(5) }>Set Power to 5</button>
               </div>
    }

    clickHandler = ()=>{
        // alert("hello there")
        // console.log(this.state.name);
        this.setState({
            power : this.state.power + 1
        })
    }

    setPowerHandler = (num)=>{
        this.setState({
            power : num
        })
    }
};

export default MainApp;