import { Component } from "react";

class MainApp extends Component{
    state = {
        show : true
    }
    render(){
        // IF ELSE
        /* if(this.state.show){
            return <div>
                    <h1>Conditional Rendering</h1>
                    <button>Hide Terms</button>
                    <hr />
                    <fieldset>
                        <legend>Terms and Conditions</legend>
                        <hr />
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae beatae delectus omnis dolore in facilis cum amet ducimus, architecto labore quia illo quisquam maiores harum voluptate nesciunt, sint nobis molestias.
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Adipisci distinctio quo fuga voluptatem atque cum eaque, alias quia repellendus commodi quidem sapiente dolorum, quos magni voluptas hic perspiciatis dicta aspernatur.
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident culpa ducimus dolores aspernatur dicta eius quasi. Magnam adipisci eaque ut, necessitatibus esse nam ullam consequuntur ea soluta nesciunt nulla quam?
                        </p>
                    </fieldset>
               </div>
        }else{
            return <div>
                    <h1>Conditional Rendering</h1>
                    <button>Show Terms</button>
                    <hr />
               </div>
        } */


        // Trenary Operator
        return <div>
                    <h1>Conditional Rendering</h1>
                    <hr />
                    { this.state.show ? <div>
                        <fieldset>
                        <legend>Terms and Conditions</legend>
                        <hr />
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae beatae delectus omnis dolore in facilis cum amet ducimus, architecto labore quia illo quisquam maiores harum voluptate nesciunt, sint nobis molestias.
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Adipisci distinctio quo fuga voluptatem atque cum eaque, alias quia repellendus commodi quidem sapiente dolorum, quos magni voluptas hic perspiciatis dicta aspernatur.
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident culpa ducimus dolores aspernatur dicta eius quasi. Magnam adipisci eaque ut, necessitatibus esse nam ullam consequuntur ea soluta nesciunt nulla quam?
                        </p>
                        <button onClick={ this.showHide }>Hide Terms</button>
                    </fieldset> 
                    </div> : <button onClick={ this.showHide }>Show Terms</button>}

                    { this.state.show !== true && "Terms are Hidden" }
               </div>
    }

    showHide = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
};

export default MainApp;